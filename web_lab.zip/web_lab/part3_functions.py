import time
import requests

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10

# Exercițiul 21. Prima funcție.
def fetch(url):
    """Returnează obiectul răspuns pentru adresa url."""
    return requests.get(url, timeout=TIMEOUT)

print(fetch(BASE_URL).status_code)

# Exercițiul 22. Returnarea unei singure valori.
def get_status(url):
    """Returnează codul de stare HTTP pentru adresa url."""
    return fetch(url).status_code

for path in ["/", "/robots.txt", "/sitemap.xml"]:
    print(path, get_status(BASE_URL + path))
    time.sleep(1)

# Exercițiul 23. Parametri impliciți.
def fetch(url, timeout=10):
    """Returnează răspunsul pentru url, cu un timeout configurabil."""
    return requests.get(url, timeout=timeout)

print(fetch(BASE_URL).status_code)
time.sleep(1)
print(fetch(BASE_URL, timeout=3).status_code)

# Exercițiul 24. O singură sarcină pe funcție.
def get_title(html):
    """Returnează titlul paginii HTML sau un șir gol dacă lipsește."""
    start = html.find("<title>")
    end = html.find("</title>")
    if start == -1 or end == -1:
        return ""
    return html[start + len("<title>"):end].strip()

print(get_title(fetch(BASE_URL).text))

# Exercițiul 25. Docstring-uri.
help(get_title)

# Exercițiul 26. Adnotări de tip.
def get_status(url: str) -> int:
    """Returnează codul de stare HTTP pentru adresa url."""
    return fetch(url).status_code

try:
    get_status(123)
except Exception as e:
    print("Eroare:", type(e).__name__, e)

# Exercițiul 27. Fără opriri neașteptate.
def page_exists(url: str) -> bool:
    """Returnează True dacă pagina răspunde cu succes, altfel False."""
    try:
        return fetch(url).ok
    except requests.RequestException:
        return False

print(page_exists(BASE_URL))
print(page_exists("https://this-domain-does-not-exist.invalid"))

# Exercițiul 28. Returnarea unui dicționar.
def check_paths(base: str, paths: list) -> dict:
    """Returnează un dicționar {cale: cod_de_stare} pentru fiecare cale."""
    results = {}
    for path in paths:
        results[path] = get_status(base + path)
        time.sleep(1)
    return results

print(check_paths(BASE_URL, ["/", "/robots.txt", "/sitemap.xml"]))

# Exercițiul 29. Argumente cu nume.
def get_header(url: str, name: str, default: str = "lipsește") -> str:
    """Returnează valoarea unui antet sau valoarea implicită dacă lipsește."""
    return fetch(url).headers.get(name, default)

print(get_header(BASE_URL, name="Server"))

# Exercițiul 30. Antete de securitate.
SECURITY_HEADERS = [
    "Strict-Transport-Security",
    "Content-Security-Policy",
    "X-Frame-Options",
    "X-Content-Type-Options",
    "Referrer-Policy",
]

def security_headers(url: str) -> dict:
    """Returnează {antet: True/False} pentru cele 5 antete de securitate."""
    headers = fetch(url).headers
    return {name: name in headers for name in SECURITY_HEADERS}

print(security_headers(BASE_URL))

# Exercițiul 31. Funcții care apelează funcții.
def score_headers(results: dict) -> str:
    """Returnează scorul antetelor de securitate sub forma 'prezente/total'."""
    return f"{sum(results.values())}/{len(results)}"

print(score_headers(security_headers(BASE_URL)))

# Exercițiul 32. Două funcții, o sarcină.
def fetch_robots(base: str):
    """Returnează textul /robots.txt sau None dacă fișierul lipsește."""
    try:
        r = fetch(base + "/robots.txt")
    except requests.RequestException:
        return None
    return r.text if r.status_code == 200 else None

def disallowed_paths(robots_text) -> list:
    """Returnează lista valorilor Disallow din robots.txt (listă goală pentru None)."""
    if robots_text is None:
        return []
    paths = []
    for line in robots_text.splitlines():
        if line.lower().startswith("disallow:"):
            value = line.split(":", 1)[1].strip()
            if value:
                paths.append(value)
    return paths

print(disallowed_paths(fetch_robots(BASE_URL)))
print(disallowed_paths(None))

# Exercițiul 33. Oricâte argumente.
def response_times(*urls) -> dict:
    """Returnează {url: secunde} pentru fiecare url primit."""
    times = {}
    for url in urls:
        start = time.perf_counter()
        fetch(url)
        times[url] = round(time.perf_counter() - start, 3)
        time.sleep(1)
    return times

print(response_times(BASE_URL, BASE_URL + "/robots.txt"))

# Exercițiul 34. Argumente cu nume colectate.
def log(message, **details):
    """Afișează mesajul urmat de fiecare detaliu, separate prin ' | '."""
    parts = [message] + [f"{k}={v}" for k, v in details.items()]
    print(" | ".join(parts))

log("verificat", url=BASE_URL, status=200)
