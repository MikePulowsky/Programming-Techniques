import csv
import json
import re
import socket
import ssl
import time
from datetime import datetime
from urllib.parse import urljoin, urlparse

import requests

BASE_URL = "https://cybercor.org"
TIMEOUT = 10

# Exercițiul 47. Constante de modul.
DEFAULT_HEADERS = {"User-Agent": "WebLab-Iurco Mihai"}

SECURITY_HEADERS = [
    "Strict-Transport-Security",
    "Content-Security-Policy",
    "X-Frame-Options",
    "X-Content-Type-Options",
    "Referrer-Policy",
]

# Exercițiul 44. Crearea unui modul.
def fetch(url, timeout=TIMEOUT):
    """Returnează răspunsul pentru url, folosind antetele implicite."""
    return requests.get(url, timeout=timeout, headers=DEFAULT_HEADERS)

def get_status(url):
    """Returnează codul de stare HTTP pentru adresa url."""
    return fetch(url).status_code

def get_title(html):
    """Returnează titlul paginii HTML sau un șir gol dacă lipsește."""
    start, end = html.find("<title>"), html.find("</title>")
    if start == -1 or end == -1:
        return ""
    return html[start + len("<title>"):end].strip()

def security_headers(url):
    """Returnează {antet: True/False} pentru cele 5 antete de securitate."""
    headers = fetch(url).headers
    return {name: name in headers for name in SECURITY_HEADERS}

def score_headers(results):
    """Returnează scorul antetelor, de forma '3/5'."""
    return f"{sum(results.values())}/{len(results)}"

def check_paths(base, paths):
    """Returnează {cale: cod_de_stare} pentru fiecare cale din listă."""
    results = {}
    for path in paths:
        try:
            results[path] = get_status(base + path)
        except requests.RequestException:
            results[path] = None
        time.sleep(1)
    return results

def fetch_robots(base):
    """Returnează textul /robots.txt sau None dacă lipsește."""
    try:
        r = fetch(base + "/robots.txt")
    except requests.RequestException:
        return None
    return r.text if r.status_code == 200 else None

def disallowed_paths(robots_text):
    """Returnează lista valorilor Disallow din robots.txt."""
    if robots_text is None:
        return []
    paths = []
    for line in robots_text.splitlines():
        if line.lower().startswith("disallow:"):
            value = line.split(":", 1)[1].strip()
            if value:
                paths.append(value)
    return paths

def extract_links(html):
    """Returnează legăturile din html, fără duplicate."""
    return list(dict.fromkeys(re.findall(r'href="([^"]+)"', html)))

def split_links(links, domain):
    """Împarte legăturile în (interne, externe) față de domeniu."""
    internal, external = [], []
    for link in links:
        full = urljoin("https://" + domain, link)
        if urlparse(full).netloc == domain:
            internal.append(full)
        else:
            external.append(full)
    return internal, external

def resolve(hostname):
    """Returnează adresa IPv4 a domeniului."""
    return socket.gethostbyname(hostname)

def cert_days_left(hostname):
    """Returnează zilele rămase până la expirarea certificatului TLS."""
    context = ssl.create_default_context()
    with socket.create_connection((hostname, 443), timeout=TIMEOUT) as sock:
        with context.wrap_socket(sock, server_hostname=hostname) as tls:
            cert = tls.getpeercert()
    return int((ssl.cert_time_to_seconds(cert["notAfter"]) - time.time()) // 86400)

# Exercițiul 49. Un raport CSV.
def write_csv_report(results, filename="report.csv"):
    """Salvează {cale: status} în CSV, cu coloanele path, status și checked_at."""
    with open(filename, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["path", "status", "checked_at"])
        for path, status in results.items():
            writer.writerow([path, status, datetime.now().isoformat()])

# Exercițiul 50. Proiect final: raportul site-ului.
def site_report(url):
    """Colectează, afișează și salvează în report.json raportul site-ului."""
    parsed = urlparse(url)
    host = parsed.netloc

    response = fetch(url)
    time.sleep(1)

    redirect_response = requests.get(
        "http://" + host, timeout=TIMEOUT, headers=DEFAULT_HEADERS
    )
    hops = redirect_response.history + [redirect_response]
    chain = []
    for i, step in enumerate(redirect_response.history):
        chain.append(f"{step.status_code} -> {hops[i + 1].url}")
    time.sleep(1)

    scores = security_headers(url)
    internal, external = split_links(extract_links(response.text), host)
    disallowed = disallowed_paths(fetch_robots(f"{parsed.scheme}://{host}"))

    try:
        days = cert_days_left(host)
    except (OSError, ssl.SSLError):
        days = None

    report = {
        "url": url,
        "status_code": response.status_code,
        "final_url": response.url,
        "title": get_title(response.text),
        "ip": resolve(host),
        "redirects": chain,
        "security_score": score_headers(scores),
        "cert_days_left": days,
        "internal_links": len(internal),
        "external_links": len(external),
        "disallowed_paths": disallowed,
    }

    print(f"=== Raport site: {url} ===")
    print("Cod de stare:", report["status_code"])
    print("Titlu:", report["title"])
    print("Adresă IP:", report["ip"])
    print("Redirecționări:", ", ".join(chain) if chain else "niciuna")
    print("Scor securitate:", report["security_score"])
    print("Certificat:", f"{days} de zile rămase" if days is not None else "indisponibil")
    print("Legături:", f"{len(internal)} interne, {len(external)} externe")
    print("Căi interzise:", ", ".join(disallowed) if disallowed else "niciuna")

    with open("report.json", "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, ensure_ascii=False)
    print("Salvat în report.json")
    return report

# Exercițiul 46. Blocul main.
if __name__ == "__main__":
    print("Autotest:", get_status("https://cybercor.org"))
