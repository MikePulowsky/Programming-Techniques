import time
import requests

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10

# Exercițiul 9. Elementele de bază ale răspunsului.
response = requests.get(BASE_URL, timeout=TIMEOUT)
print(response.status_code)
print(response.ok)
print(response.url)
print(response.encoding)

# Exercițiul 10. Tratarea erorilor cu o metodă.
response.raise_for_status()
time.sleep(1)
try:
    r = requests.get(BASE_URL + "/this-page-does-not-exist", timeout=TIMEOUT)
    r.raise_for_status()
except requests.HTTPError as e:
    print("Pagina nu a fost găsită, dar programul continuă. Detalii:", e)

# Exercițiul 11. Toate antetele.
for name, value in response.headers.items():
    print(f"{name}: {value}")

# Exercițiul 12. Metode de dicționar.
print(response.headers.get("Server", "lipsește"))
print(response.headers.get("Content-Type", "lipsește"))
print(response.headers.get("content-type", "lipsește"))

# Exercițiul 13. Înlănțuirea metodelor de șir.
print(response.text.lower().count("cyber"))

# Exercițiul 14. Găsirea titlului.
html = response.text
start = html.find("<title>") + len("<title>")
end = html.find("</title>")
print(html[start:end].strip())

# Exercițiul 15. Numărarea liniilor.
lines = html.splitlines()
print(len(lines), "linii")
print(len(max(lines, key=len)), "caractere în cea mai lungă linie")

# Exercițiul 16. Verificarea HTTPS.
if response.url.startswith("https://"):
    print("Conexiune securizată")
else:
    print("Conexiune nesecurizată")

# Exercițiul 17. Urmărirea redirecționărilor.
time.sleep(1)
r = requests.get("http://cybercor.org", timeout=TIMEOUT)
for step in r.history:
    print(step.status_code, step.url)
print("URL final:", r.url)

# Exercițiul 18. HEAD versus GET.
time.sleep(1)
h = requests.head(BASE_URL, timeout=TIMEOUT)
g = requests.get(BASE_URL, timeout=TIMEOUT)
print(len(h.content), len(g.content))

# Exercițiul 19. Cookie-uri.
if len(response.cookies) == 0:
    print("Niciun cookie setat")
else:
    for c in response.cookies:
        print(c.name, c.secure)

# Exercițiul 20. Sesiuni.
time.sleep(1)
session = requests.Session()
session.headers.update({"User-Agent": "WebLab-Iurco Mihai"})
r = session.get(ECHO_URL + "/headers", timeout=TIMEOUT)
print(r.json()["headers"]["User-Agent"])
