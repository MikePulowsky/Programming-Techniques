BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10

# Exercițiul 1. Primul import.
import requests
print(requests.__version__)
import urllib.request

# Exercițiul 2. Două stiluri de import.
response = requests.get(BASE_URL, timeout=TIMEOUT)
print(response.status_code)

from requests import get
response = get(BASE_URL, timeout=TIMEOUT)
print(response.status_code)

# Exercițiul 3. Alias-uri.
import requests as rq
response = rq.get(BASE_URL, timeout=TIMEOUT)
print(response.status_code)

# Exercițiul 4. Doar biblioteca standard.
import urllib.request
import urllib.error

req = urllib.request.Request(
    BASE_URL,
    headers={"User-Agent": "WebLab-Popescu Ion"},
)

try:
    with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
        print(resp.status)
        body = resp.read().decode("utf-8")
        print(body[:200])
except urllib.error.HTTPError as e:
    print("Serverul a răspuns cu eroare:", e.code, e.reason)

# Exercițiul 5. Priviți în interiorul unui modul.
print(dir(requests))

# Exercițiul 6. Citiți documentația.
help(requests.get)
response = requests.get(BASE_URL, timeout=TIMEOUT)

# Exercițiul 7. Cronometrarea unei cereri.
import time
start = time.perf_counter()
response = requests.get(BASE_URL, timeout=TIMEOUT)
end = time.perf_counter()
print(f"perf_counter: {end - start:.3f} s")
print(f"response.elapsed: {response.elapsed.total_seconds():.3f} s")

# Exercițiul 8. Când un import eșuează.
try:
    import bs4
except ImportError:
    print("Instalați modulul cu: pip install beautifulsoup4")
