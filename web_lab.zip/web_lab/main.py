import argparse

# Exercițiul 44. Crearea unui modul.
import webtools

print(webtools.get_title(webtools.fetch(webtools.BASE_URL).text))

# Exercițiul 45. Importarea anumitor nume.
from webtools import get_title, security_headers, check_paths, write_csv_report, site_report, fetch

# Exercițiul 47. Constante de modul.
from webtools import DEFAULT_HEADERS

print(DEFAULT_HEADERS)

# Exercițiul 48. Argumente din linia de comandă.
parser = argparse.ArgumentParser(description="Raport despre un site web")
parser.add_argument("url", help="adresa site-ului, de exemplu https://cybercor.org")
args = parser.parse_args()

print(get_title(fetch(args.url).text))
print(security_headers(args.url))

# Exercițiul 49. Un raport CSV.
results = check_paths(args.url, ["/", "/robots.txt", "/sitemap.xml"])
write_csv_report(results, "report.csv")

# Exercițiul 50. Proiect final: raportul site-ului.
site_report(args.url)
