import hashlib
import json
import re
import socket
import ssl
import time
from html.parser import HTMLParser
from urllib.parse import urljoin, urlparse

import requests

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10

# Exercițiul 35. Descompunerea unui URL.
p = urlparse("https://cybercor.org/path?x=1#top")
print(p.scheme, p.netloc, p.path, p.query, p.fragment)

# Exercițiul 36. Compunerea URL-urilor.
for link in ["/about", "contact.html", "../index.html"]:
    print(urljoin(BASE_URL, link))

# Exercițiul 37. Extragerea legăturilor.
def extract_links(html: str) -> list:
    """Returnează legăturile (href) din html, fără duplicate, în ordinea apariției."""
    links = re.findall(r'href="([^"]+)"', html)
    return list(dict.fromkeys(links))

html = requests.get(BASE_URL, timeout=TIMEOUT).text
print(extract_links(html))

# Exercițiul 38. Interne sau externe?
def split_links(links: list, domain: str):
    """Împarte legăturile în (interne, externe) față de domeniul dat."""
    internal, external = [], []
    for link in links:
        full = urljoin("https://" + domain, link)
        if urlparse(full).netloc == domain:
            internal.append(full)
        else:
            external.append(full)
    return internal, external

print(split_links(extract_links(html), "cybercor.org"))

# Exercițiul 39. Propriile metode.
class ImageFinder(HTMLParser):
    """Colectează atributul src al fiecărui tag <img>."""

    def __init__(self):
        super().__init__()
        self.images = []

    def handle_starttag(self, tag, attrs):
        if tag == "img":
            src = dict(attrs).get("src")
            if src:
                self.images.append(src)

test_html = """
<html><body>
<img src="/logo.png" alt="Logo">
<IMG SRC="poza.jpg">
<img alt="imagine fără src">
<img src="https://cdn.example.com/banner.webp" />
<a href="/despre">Aceasta nu este o imagine</a>
</body></html>
"""

finder = ImageFinder()
finder.feed(test_html)
print(finder.images)
assert finder.images == [
    "/logo.png",
    "poza.jpg",
    "https://cdn.example.com/banner.webp",
], "Parserul nu a găsit exact imaginile așteptate"
print("Testul a trecut!")

response = requests.get(BASE_URL, timeout=TIMEOUT)
finder = ImageFinder()
finder.feed(response.text)
print(len(finder.images), "imagini găsite")
for src in finder.images:
    print(src)
print("<img în text:", response.text.lower().count("<img"))

# Exercițiul 40. Amprenta paginii.
def page_fingerprint(url: str) -> str:
    """Returnează amprenta SHA-256 a conținutului paginii."""
    return hashlib.sha256(requests.get(url, timeout=TIMEOUT).content).hexdigest()

a = page_fingerprint(BASE_URL)
time.sleep(1)
b = page_fingerprint(BASE_URL)
print(a)
print(b)
print(a == b)

# Exercițiul 41. Salvarea în JSON.
with open("headers.json", "w", encoding="utf-8") as f:
    json.dump(dict(response.headers), f, indent=2)
with open("headers.json", encoding="utf-8") as f:
    loaded = json.load(f)
print(loaded.get("Content-Type"))

# Exercițiul 42. Interogare DNS.
def resolve(hostname: str) -> str:
    """Returnează adresa IPv4 a unui nume de domeniu."""
    return socket.gethostbyname(hostname)

print(resolve("cybercor.org"))

# Exercițiul 43. Expirarea certificatului.
def cert_days_left(hostname: str) -> int:
    """Returnează numărul de zile rămase până la expirarea certificatului TLS."""
    context = ssl.create_default_context()
    with socket.create_connection((hostname, 443), timeout=TIMEOUT) as sock:
        with context.wrap_socket(sock, server_hostname=hostname) as tls:
            cert = tls.getpeercert()
    expires = ssl.cert_time_to_seconds(cert["notAfter"])
    return int((expires - time.time()) // 86400)

print(cert_days_left("cybercor.org"))
